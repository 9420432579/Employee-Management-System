package Employee_management_system;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class v extends JFrame{
    JTable table;
    DefaultTableModel model;
    v(){   

        String[] coloum={"id","name","Contact","username","password"};
        model=new DefaultTableModel(coloum,5);
        table=new JTable(model);

        JScrollPane list = new JScrollPane(table) ;
        add(list);
        setTitle("View Employee"); 
        setSize(1170,650);
        setLocation(150, 80);
        setVisible(true);
        setLocale(null);

    }   
    public static void main(String[] args) {
        new v();
    }

}