package Employee_management_system;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class View extends JFrame {

    JTable table; // Table to display employee data
    DefaultTableModel model; // Table model to manage data in the JTable

    View() {
        // Set up the main frame
        setTitle("View Employees");
        setSize(900, 500);
        setLocationRelativeTo(null); // Center the window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create and add the heading label
        JLabel heading = new JLabel("All Employees", SwingConstants.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 24));
        heading.setForeground(Color.red);
        add(heading, BorderLayout.NORTH);

        
        // Define column names for the employee table
        String[] columns = {"ID", "Name", "Username", "Email", "Contact", "Password"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);

        // Load employee records from database
        loadEmployees();

        // Add the table inside a scroll pane to handle large data
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Back button to return to dashboard
        JButton back = new JButton("Back");
        back.setFont(new Font("Arial", Font.BOLD, 14)); 
        back.setBackground(Color.BLUE);
        back.setForeground(Color.WHITE);
        back.addActionListener(e -> {
            new dashbord(); 
            dispose();      // Close the current window
        });

        // Add the button to a panel and add to the bottom of the frame
        JPanel southPanel = new JPanel();
        southPanel.add(back);
        add(southPanel, BorderLayout.SOUTH);

        // Make the window visible
        setVisible(true);
    }

    private void loadEmployees() {
        try {
            connect conn = new connect(); // Establish DB connection
            String query = "SELECT * FROM Employee"; // SQL query
            PreparedStatement pst = conn.connection.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            // Iterate through the result set and populate the table
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("username"),
                    rs.getString("email"),
                    rs.getString("contact"),
                    rs.getString("password")
                };
                model.addRow(row); // Add row to the model
            }

        } catch (SQLException e) {
            // Show error if any issue occurs while fetching data
            JOptionPane.showMessageDialog(null, "Error loading employees.");
            e.printStackTrace();
        }
    }

    // Main method to launch the application
    public static void main(String[] args) {
        new View();
    }
}
