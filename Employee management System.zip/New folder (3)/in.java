
import javax.swing.*;
class in extends JFrame{

   in(){
      

      setSize(1170,650);
      setLayout(null);
      setLocation(150, 40);
      setVisible(true);
   }
   public static void main(String[] args){
      new in();
   }
}